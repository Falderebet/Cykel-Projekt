# TMRh20 2014 - Newly Optimized Network Layer for nRF24L01(+) radios

Please see the full documentation at http://tmrh20.github.io/RF24Network/

See http://tmrh20.github.io/RF24/index.html for general RF24 configuration and setup
See http://tmrh20.github.io/RF24/Linux.html and http://tmrh20.github.io/RF24/RPi.html for Linux/RPi related config/setup
